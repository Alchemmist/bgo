clear_sunny = " \\ | / \n - O -  \n / | \\ "

clear_night = "  .   * \n*    . O\n. . *  ."
partial_clouds = " \\ /(  )\n- O(    )\n / (  )  "

clouds = " ( )()_ \n(      )\n (  )() "

drizzle = "'  '    '\n '   ' ' \n'    '   '"

rain = "' '' ' '\n'' ' ' '\n' ' '' '"


snow = "* '* ' *\n'* ' * '\n*' * ' *"

fog = "-- _ --\n-__-- -\n- _--__"

thunderstorm = "c__ -- _\n-- _-c__\nc-- c_ -"

everything_else = "c__ ''' '\n' '' c___\nc__ ' 'c_"
